# tcp_nanqinlang

[![build](https://github.com/nanqinlang/SVG/blob/master/build%20passing.svg)](https://github.com/tcp-nanqinlang/lkl-rinetd)
[![language1](https://github.com/nanqinlang/SVG/blob/master/language-c-blue.svg)](https://github.com/tcp-nanqinlang/lkl-rinetd)
[![language2](https://github.com/nanqinlang/SVG/blob/master/language-shell-blue.svg)](https://github.com/tcp-nanqinlang/lkl-rinetd)
[![author](https://github.com/nanqinlang/SVG/blob/master/author-nanqinlang-lightgrey.svg)](https://github.com/tcp-nanqinlang/lkl-rinetd)
[![license](https://github.com/nanqinlang/SVG/blob/master/license-GPLv3-orange.svg)](https://github.com/tcp-nanqinlang/lkl-rinetd)

`lkl` mode via `rinetd`, worked for only `OpenVZ` virtualization.

## according
Update History  
https://github.com/tcp-nanqinlang/lkl-rinetd/releases

中文文档  
https://sometimesnaive.org/article/54
